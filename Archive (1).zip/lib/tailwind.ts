import { create } from "twrnc";

const tw = create(require(`../tailwind.config.js`))

export default tw;
